import xml.etree.ElementTree as ET

##############################################################
#
# Purpose: Illustrate processing a cb2xml xml file in python.
#  Author: Bruce Martin
#
##############################################################

def getFrom(d, key):
    r=''
    if key in d.attrib:
        r = d.attrib[key]
    return r
    
def getFrom1(d, key):
    r=''
    if key in d.attrib:
        r = key + '=' + d.attrib[key]
    return r
 
##########################################################################
#
# Purpose: Print one item
#
# Items are a recursive tag in cb2xml (i.e. Items can have Items inside them)
# hence the recursive call to printItem 
#
##########################################################################
def printItem(indent, item):
    print indent, item.attrib['name'], item.attrib['position'],	item.attrib['storage-length'],	getFrom(item, 'display-length'), getFrom(item, 'picture'), getFrom1(item, 'usage'), getFrom1(item, 'numeric'), getFrom1(item, 'signed')
    for child in item.findall('item'):
	printItem(indent + "    ", child)

#########################################################################
#
# Process the Xml, print the copybook tag then run through the 
# the items in the copybook (and print them via the printItem method).
#
#########################################################################
tree = ET.parse('cbl2xml_Test110.cbl.xml')
root = tree.getroot()

print ">> ", root.tag, root.attrib['filename']

for child in root.findall('item'):
    printItem("    ", child)
    

