#! /bin/sh

    java -jar ../lib/cb2xml.jar cbl2xml_Test102.cbl > cbl2xml_Test102.cbl.xml
    java -jar ../lib/cb2xml.jar cbl2xml_Test110.cbl > cbl2xml_Test110.cbl.xml