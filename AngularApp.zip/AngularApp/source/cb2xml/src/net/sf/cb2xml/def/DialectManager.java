package net.sf.cb2xml.def;

public class DialectManager {
	public static final NumericDefinition MAINFRAME_NUMERIC_DEFINITION = new BasicNumericDefinition(
			"Mainframe", BasicNumericDefinition.MAINFRAME_SIZES, BasicNumericDefinition.MAINFRAME_SYNC, false, 4 ,4
	);

}
