# Cb2xml version 0.95.1

This version of cb2xml contains some minor of changes that I thought after the release of version 0.95 

## Uses of cb2xml

* Convert a **Cobol Copybook** to an equivalent **Xml** file description
* Convert a **Cobol Data** file to **Xml** file (xml2dat program).
* Convert a **Xml** file to a **Cobol Data** (dat2xml program).

The **Cobol Copybook** to **Xml** is used in several other projects + several commercial packages to analyse Cobol-Copybooks.

The *Cobol-to-Data* and *Data-to-Copybook* programs are fairly limited, they can only handle copybooks character / edited-numeric
copybooks. 

## Changes (0.95.1)

* Created a new class **Cb2Xml2** which is like the *Cb2Xml* class except it does not trap errors !!!
* Minor improvements in the error messages from the Cobol Parser.
* Created *DTD* and *Xsd* schemas for the Xml created by **cb2xml**. These can be used to generate classes for c#, java etc.
* Created java - Jaxb example programs for processing *cb2xml Xml* using **jaxb**.
* Created python program to print cb2xml Xml contents .

## Changes (0.95)

* improved support for P picture character, new assumed digits tag + Scale can be negative (due to P picture option).
* Introduced constant class for the attributes used by Cb2xml. This allows other projects to integrate better with cb2xml
* Most methods accept stream as well File (Feature request 1)
* Support for Hex literals (patch 1)
* Support for sync keyword
* Fixed issue with fields starting with numbers
* Fixed issue with comments at start of copybook in dat2xml and xml2dat
* Fixed issue with "anonymous" REDEFINES (problem 12)
* Fixed issue with sign separate (problem 6)
* Option to pass start/end  columns to the CobolPreprocessor (instead of using the cb2xml.properties file).
* Added some basic Automated Tests, this will allow regular releases in the future.
* dat2xml - trim numbers
* dat2xml - Fixed issue with occurs (problem 4 and 10)
* xml2dat - Changed to set field to spaces (when tag is absent in the Xml and no initialize is set). (problem 11).
* xml2dat - fix for when incoming data is not the expected cobol length
* xml2dat - changed to handle multiple records



## Future Changes

* I am hoping to bring support for other Cobol Dialects to cb2xml.
